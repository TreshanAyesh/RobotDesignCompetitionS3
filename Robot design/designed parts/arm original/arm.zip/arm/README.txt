uArm is designed by UFacotry team (www.ufactory.cc). It is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)License.The full terms of this license can be read at:
http://creativecommons.org/licenses/by-nc-sa/4.0/
